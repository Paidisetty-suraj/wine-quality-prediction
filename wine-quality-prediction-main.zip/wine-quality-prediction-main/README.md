# wine-quality-prediction
Determines the quality of wine using linear regression learning model.Involves parameter and hyperparameter tuning.
Model learning using both stocastic and batch mode gradient descent.
Includes PPT(describing entire project) and result sheet(results obtained after training with different parameters,split ratios,hyperparameters).
